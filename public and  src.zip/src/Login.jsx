import React, { useState, useContext } from 'react';
import { useNavigate } from 'react-router-dom';
import { AuthContext } from './context/AuthContext';

const Login = () => {
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const { login } = useContext(AuthContext);
  const navigate = useNavigate();

  const handleSubmit = (e) => {
    e.preventDefault();

    if (!email || !password) {
      alert('Please fill in all fields');
      return;
    }

    login(email);
    navigate('/orderonline'); // redirect to orderonline after login
  };

  return (
    <>
    <div className="min-h-screen flex pt-[60px] justify-center bg-white">
      <div className="w-[600px] max-w-md px-[6px] text-[sans] py-[20px] ">
        <h1 className="text-3xl font-bold mb-[20px] text-center">Login</h1>
        <p className="text-center text-gray-600 mb-[8px]"></p>
        <form onSubmit={handleSubmit} className="space-y-4">
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-[10px]">Email address</label>
            <input
              type="email"
              className="w-full border border-gray-300 px-[10px] py-[8px] mb-[30px] rounded-md focus:outline-none focus:ring-2 focus:ring-black"
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              placeholder="Email"
              required
            />
          </div>

          <div>
            <label className="block text-sm font-medium text-gray-700 mb-[10px]">Password</label>
            <input
              type="password"
              className="w-full border border-gray-300 px-[10px] py-[8px] rounded-md focus:outline-none focus:ring-2 focus:ring-black"
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              placeholder="Password"
              required
            />
          </div>

          <div className="text-sm text-center m-[12px]">
            {/* <a href="#" className="text-[#4b2f32] underline">Forgot your password?</a> */}
          </div>

          <button
            type="submit"
            className="w-full bg-[#4b2f32] text-[white] text-[18px] mt-[10px] mb-[10px] py-[12px] rounded-md hover:bg-gray-900"
          >
            Login
          </button>
        </form>

        {/* <div className="mt-[6px] text-center text-sm">
          Don't have an account? <a href="#" className="underline text-[#4b2f32]">Create account</a>
        </div> */}
      </div>
    </div>
    <div>
      <img src="bean_border-1.png" alt="" className="w-full block" />
    </div>
    </>
  );
};

export default Login;
